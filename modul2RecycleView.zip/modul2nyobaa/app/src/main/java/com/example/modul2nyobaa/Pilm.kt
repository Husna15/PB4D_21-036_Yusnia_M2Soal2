package com.example.modul2nyobaa

import android.os.Parcel
import android.os.Parcelable

data class Pilm(val image:Int, val name:String): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()!!
    ) {
    }
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(image)
        parcel.writeString(name)
    }
    override fun describeContents(): Int {
        return 0
    }
    companion object CREATOR : Parcelable.Creator<Pilm> {
        override fun createFromParcel(parcel: Parcel): Pilm {
            return Pilm(parcel)
        }
        override fun newArray(size: Int): Array<Pilm?> {
            return arrayOfNulls(size)
        }
    }
}