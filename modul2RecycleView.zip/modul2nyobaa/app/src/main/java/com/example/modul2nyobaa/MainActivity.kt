package com.example.modul2nyobaa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var filmList: ArrayList<Pilm>
    private lateinit var pilmAdapter: PilmAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView= findViewById(R.id.recyclerView)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)

        filmList = ArrayList()

        filmList.add(Pilm(R.drawable.filmm,"Film 1"))
        filmList.add(Pilm(R.drawable.film1,"Film 2"))
        filmList.add(Pilm(R.drawable.film2,"Film 3"))
        filmList.add(Pilm(R.drawable.film3,"Film 4"))
        filmList.add(Pilm(R.drawable.film4,"Film 5"))
        filmList.add(Pilm(R.drawable.film5,"Film 6"))
        filmList.add(Pilm(R.drawable.film4,"Film 7"))
        filmList.add(Pilm(R.drawable.film5,"Film 8"))
        filmList.add(Pilm(R.drawable.film3,"Film 9"))
        filmList.add(Pilm(R.drawable.film2,"Film 10"))
        filmList.add(Pilm(R.drawable.film3,"Film 11"))
        filmList.add(Pilm(R.drawable.film2,"Film 12"))
        filmList.add(Pilm(R.drawable.filmm,"Film 13"))
        filmList.add(Pilm(R.drawable.film5,"Film 14"))
        filmList.add(Pilm(R.drawable.film1,"Film 15"))


        pilmAdapter = PilmAdapter(filmList)
        recyclerView.adapter = pilmAdapter

    }
}

